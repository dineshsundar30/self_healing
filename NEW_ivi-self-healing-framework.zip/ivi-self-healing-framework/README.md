# IVI Self-Healing Framework 🚗

AI-powered self-healing automation framework for Robot Framework + Appium.

## Features
- Auto-heals broken locators
- Uses heuristic + AI fallback
- Stores memory using ChromaDB
- Reduces maintenance effort

## Run
pip install -r requirements.txt
robot --listener healing.listener tests/
