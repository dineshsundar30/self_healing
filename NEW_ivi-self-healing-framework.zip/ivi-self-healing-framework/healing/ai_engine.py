def suggest_locator_with_ai(old_locator, page_source):
    keywords = old_locator.lower().replace("//", "").split()
    best_match = None
    best_score = 0

    for line in page_source.splitlines():
        score = sum(1 for kw in keywords if kw in line.lower())
        if score > best_score:
            best_score = score
            best_match = line.strip()

    if best_match:
        return f"xpath=//*[contains(@text,'{keywords[0]}')]"
    return None
