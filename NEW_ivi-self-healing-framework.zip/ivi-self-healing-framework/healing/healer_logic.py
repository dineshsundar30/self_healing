import xml.etree.ElementTree as ET
import json
import os
import re
from typing import Optional, List, Tuple

from healing.vector_store import search_similar, store_healing
from healing.ai_engine import suggest_locator_with_ai

HEALED_LOCATORS_FILE = "healed_locators.json"

# Words too common / structural to be discriminating in resource-ids
_GENERIC_WORDS = {
    'android', 'systemui', 'renault', 'mydriving', 'driving',
    'layout', 'widget', 'frame', 'linear', 'relative', 'scroll',
    'recycler', 'coordinator', 'constraint', 'include',
    'view', 'button', 'image',
    'car', 'com', 'id', 'main', 'root', 'page', 'item', 'list',
    'container', 'content', 'panel', 'group', 'holder',
}

_MIN_KW_LEN = 3


# =========================
# MAIN HEALING LOGIC
# =========================
def _main_healing_logic(old_locator: str, page_source_xml: str) -> Optional[str]:

    # 1. JSON cache
    cached = _lookup_cache(old_locator)
    if cached:
        return cached

    # 2. Extract value
    search_value = _extract_search_value(old_locator)
    if not search_value:
        return None

    # 3. Build keywords
    keywords = _build_keywords(search_value)
    if not keywords:
        return None

    # 4. Parse XML
    try:
        root = ET.fromstring(page_source_xml.encode('utf-8'))
    except Exception:
        return None

    # 5. Find candidates
    candidates: List[Tuple[int, int, str]] = []

    for node in root.iter():
        attribs = node.attrib
        raw_id = attribs.get('resource-id', '')
        raw_text = attribs.get('text', '')
        raw_desc = attribs.get('content-desc', '')

        norm_id = raw_id.lower()
        norm_text = raw_text.lower()
        norm_desc = raw_desc.lower()

        local_id = norm_id.split(':id/')[-1] if ':id/' in norm_id else norm_id

        score = sum(
            1 for kw in keywords
            if kw in local_id or kw in norm_text or kw in norm_desc
        )

        if score == 0:
            continue

        if raw_id:
            xpath, priority = f"//*[@resource-id='{raw_id}']", 0
        elif raw_desc:
            xpath, priority = f"//*[@content-desc='{raw_desc}']", 1
        elif raw_text:
            xpath, priority = f"//*[@text='{raw_text}']", 2
        else:
            continue

        if xpath == old_locator:
            continue

        candidates.append((score, priority, xpath))

    if not candidates:
        return None

    candidates.sort(key=lambda x: (-x[0], x[1]))
    best_xpath = candidates[0][2]

    _save_cache(old_locator, best_xpath)
    return best_xpath


# =========================
# FINAL ENTRY FUNCTION
# =========================
def find_healed_locator(old_locator: str, page_source_xml: str) -> Optional[str]:

    # 1. Vector DB memory
    memory = search_similar(old_locator)
    if memory:
        return memory

    # 2. Heuristic logic
    healed = _main_healing_logic(old_locator, page_source_xml)
    if healed:
        store_healing(old_locator, healed)
        return healed

    # 3. AI fallback
    ai_result = suggest_locator_with_ai(old_locator, page_source_xml)
    if ai_result:
        store_healing(old_locator, ai_result)
        return ai_result

    return None


# =========================
# HELPERS
# =========================

def _split_camel(s: str) -> List[str]:
    return re.sub(r'([A-Z])', r' \1', s).split()


def _extract_search_value(locator: str) -> str:
    if locator.startswith('//'):
        return locator

    if '=' in locator:
        prefix, _, rest = locator.partition('=')
        if prefix.strip().lower() in {
            'id', 'xpath', 'name', 'text', 'class', 'accessibility_id'
        }:
            return rest.strip()

    return locator.strip()


def _build_keywords(search_value: str) -> List[str]:

    if search_value.startswith('//'):
        quoted = re.findall(r"['\"]([^'\"]+)['\"]", search_value)
        raw = ' '.join(quoted) if quoted else search_value
    else:
        raw = search_value

    if ':id/' in raw:
        raw = raw.split(':id/')[-1]

    camel_parts = _split_camel(raw)

    tokens = []
    for part in camel_parts:
        sub = re.sub(r'[^a-zA-Z0-9]', ' ', part).split()
        tokens.extend(sub)

    keywords = [
        t.lower() for t in tokens
        if len(t) >= _MIN_KW_LEN and t.lower() not in _GENERIC_WORDS
    ]

    return list(dict.fromkeys(keywords))


def _lookup_cache(old_locator: str) -> Optional[str]:
    if not os.path.exists(HEALED_LOCATORS_FILE):
        return None

    try:
        with open(HEALED_LOCATORS_FILE, 'r') as f:
            return json.load(f).get(old_locator)
    except Exception:
        return None


def _save_cache(old: str, new: str):
    cache = {}

    if os.path.exists(HEALED_LOCATORS_FILE):
        try:
            with open(HEALED_LOCATORS_FILE, 'r') as f:
                cache = json.load(f)
        except Exception:
            cache = {}

    cache[old] = new

    try:
        with open(HEALED_LOCATORS_FILE, 'w') as f:
            json.dump(cache, f, indent=4)
    except Exception:
        pass