import chromadb

client = chromadb.Client()
collection = client.get_or_create_collection("healing_memory")

def store_healing(old_locator, new_locator):
    collection.add(
        documents=[new_locator],
        metadatas=[{"old": old_locator}],
        ids=[old_locator]
    )

def search_similar(locator):
    try:
        results = collection.query(query_texts=[locator], n_results=1)
        if results["documents"] and results["documents"][0]:
            return results["documents"][0][0]
    except Exception:
        return None
    return None
