*** Settings ***
Library    AppiumLibrary

*** Test Cases ***
Sample Test
    Open Application    http://localhost:4723/wd/hub    platformName=Android
    Click Element    xpath=//android.widget.Button[@text='Login']
